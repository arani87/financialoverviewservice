package com.beyondbanking.ssh.financialoverviewservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinancialoverviewserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinancialoverviewserviceApplication.class, args);
    }
}
