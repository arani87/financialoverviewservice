package com.beyondbanking.ssh.financialoverviewservice.exceptions;

public class FinancialOverviewAPIException extends Throwable {
    public FinancialOverviewAPIException(String message) {
        super(message);
    }
}
